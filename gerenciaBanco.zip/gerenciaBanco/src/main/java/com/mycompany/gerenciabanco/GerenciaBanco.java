/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.gerenciabanco;
import java.util.Scanner;
import java.util.Locale;
/**
 *
 * @author daniel Cirino
 */
import java.util.Scanner;
import java.util.Locale;

public class GerenciaBanco {

    public static void MenuInicial() {
        System.out.println("Digite a opção desejada");
        System.out.println("1-Depósito");
        System.out.println("2-Saque");
        System.out.println("3-Exibir Saldo");
        System.out.println("4-Sair");
    }

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        scanner.useLocale(Locale.US);
        var saldo = 0.0;

        MenuInicial();
        var opcao = scanner.nextInt();
        while (opcao != 4) {
            if (opcao == 1) {
                System.out.println("Digite o valor do depósito");
                var valorDeposito = scanner.nextDouble();
                if (valorDeposito < 0.0) {
                    System.out.println("Valor Inválido");
                } else {
                    saldo += valorDeposito;
                }
            } else if (opcao == 2) {
                System.out.println("Digite o valor de saque");
                var valorSaque = scanner.nextDouble();
                if (saldo - valorSaque < 0.0) {
                    System.out.println("Valor Inválido");
                } else {
                    saldo -= valorSaque;
                }
            } else if (opcao == 3) {
                System.out.println("Seu saldo é: " + saldo);
            }
            MenuInicial();
            opcao = scanner.nextInt();
        }
    }
}

class Conta {
    private double saldo;

    public Conta(double saldo) {
        this.saldo = saldo;
    }

    public boolean depositar(double valorDeposito) {
        if (valorDeposito < 0.0) {
            return false;
        }
        this.saldo += valorDeposito;
        return true;
    }

    public boolean sacar(double valorSaque) {
        if (saldo - valorSaque < 0.0) {
            return false;
        }
        saldo -= valorSaque;
        return true;
    }

    public double getSaldo() {
        return this.saldo;
    }
}



